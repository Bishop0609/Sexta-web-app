import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:sexta_app/core/theme/app_theme.dart';
import 'package:sexta_app/models/guard_roster_model.dart';
import 'package:sexta_app/models/user_model.dart';
import 'package:sexta_app/providers/user_provider.dart';
import 'package:sexta_app/services/guard_roster_service.dart';
import 'package:sexta_app/services/user_service.dart';
import 'package:sexta_app/widgets/app_drawer.dart';
import 'package:sexta_app/widgets/guard_roster_card.dart';

/// Screen for generating and editing weekly guard roster
class GenerateGuardRosterScreen extends ConsumerStatefulWidget {
  const GenerateGuardRosterScreen({super.key});

  @override
  ConsumerState<GenerateGuardRosterScreen> createState() =>
      _GenerateGuardRosterScreenState();
}

class _GenerateGuardRosterScreenState
    extends ConsumerState<GenerateGuardRosterScreen> {
  final _guardRosterService = GuardRosterService();
  final _userService = UserService();

  DateTime _selectedWeekStart = DateTime.now();
  GuardRosterWeekly? _weeklyRoster;
  List<GuardRosterDaily> _dailyRosters = [];
  List<UserModel> _allUsers = [];
  bool _isLoading = false;
  bool _isGenerating = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _selectedWeekStart = _guardRosterService.getWeekStart(DateTime.now());
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    try {
      // Load all users
      final users = await _userService.getAllUsers();
      
      // Check if roster exists for this week
      final weeklyRoster = await _guardRosterService.getWeeklyRoster(
        _selectedWeekStart,
      );

      List<GuardRosterDaily> dailyRosters = [];
      if (weeklyRoster != null) {
        dailyRosters = await _guardRosterService.getDailyRostersForWeek(
          weeklyRoster.id,
        );
      }

      setState(() {
        _allUsers = users;
        _weeklyRoster = weeklyRoster;
        _dailyRosters = dailyRosters;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al cargar datos: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _generateRoster() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Generar Rol Automático'),
        content: Text(
          _weeklyRoster != null
              ? '¿Regenerar el rol existente? Se perderán las asignaciones actuales.'
              : '¿Generar rol automático basado en disponibilidad registrada?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Generar'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() => _isGenerating = true);

    try {
      final currentUser = ref.read(currentUserProvider);
      if (currentUser == null) throw Exception('Usuario no autenticado');

      final weekEnd = _guardRosterService.getWeekEnd(_selectedWeekStart);

      // Create or get weekly roster
      GuardRosterWeekly weeklyRoster;
      if (_weeklyRoster != null) {
        weeklyRoster = _weeklyRoster!;
      } else {
        weeklyRoster = await _guardRosterService.createWeeklyRoster(
          weekStart: _selectedWeekStart,
          weekEnd: weekEnd,
        );
      }

      // Generate roster automatically
      await _guardRosterService.generateWeeklyRoster(
        rosterWeekId: weeklyRoster.id,
        weekStart: _selectedWeekStart,
        allUsers: _allUsers,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Rol generado exitosamente'),
            backgroundColor: AppTheme.efectivaColor,
          ),
        );
      }

      await _loadData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al generar rol: $e')),
        );
      }
    } finally {
      setState(() => _isGenerating = false);
    }
  }

  Future<void> _publishRoster() async {
    if (_weeklyRoster == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Publicar Rol'),
        content: const Text(
          '¿Publicar este rol? Los bomberos podrán verlo en "Ver Mi Rol".',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.efectivaColor,
            ),
            child: const Text('Publicar'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await _guardRosterService.publishWeeklyRoster(_weeklyRoster!.id);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Rol publicado exitosamente'),
            backgroundColor: AppTheme.efectivaColor,
          ),
        );
      }

      await _loadData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al publicar: $e')),
        );
      }
    }
  }

  Future<void> _deleteRoster() async {
    if (_weeklyRoster == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Eliminar Rol'),
        content: const Text(
          '¿Eliminar este rol? Esta acción no se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await _guardRosterService.deleteWeeklyRoster(_weeklyRoster!.id);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Rol eliminado'),
            backgroundColor: AppTheme.warningColor,
          ),
        );
      }

      setState(() {
        _weeklyRoster = null;
        _dailyRosters = [];
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al eliminar: $e')),
        );
      }
    }
  }

  void _previousWeek() {
    setState(() {
      _selectedWeekStart = _selectedWeekStart.subtract(const Duration(days: 7));
    });
    _loadData();
  }

  void _nextWeek() {
    setState(() {
      _selectedWeekStart = _selectedWeekStart.add(const Duration(days: 7));
    });
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    final weekEnd = _guardRosterService.getWeekEnd(_selectedWeekStart);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Generar Rol Semanal'),
        actions: [
          if (_weeklyRoster != null && _weeklyRoster!.isDraft)
            IconButton(
              icon: const Icon(Icons.publish),
              onPressed: _publishRoster,
              tooltip: 'Publicar rol',
            ),
          if (_weeklyRoster != null)
            PopupMenuButton(
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      Icon(Icons.delete, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Eliminar rol'),
                    ],
                  ),
                ),
              ],
              onSelected: (value) {
                if (value == 'delete') _deleteRoster();
              },
            ),
        ],
      ),
      drawer: const AppDrawer(),
      body: Column(
        children: [
          // Week selector
          Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.chevron_left),
                        onPressed: _previousWeek,
                      ),
                      Expanded(
                        child: Column(
                          children: [
                            Text(
                              'Semana del',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            Text(
                              '${DateFormat('dd MMM', 'es_ES').format(_selectedWeekStart)} - ${DateFormat('dd MMM yyyy', 'es_ES').format(weekEnd)}',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.chevron_right),
                        onPressed: _nextWeek,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Generate button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _isGenerating ? null : _generateRoster,
                      icon: _isGenerating
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.auto_awesome),
                      label: Text(
                        _isGenerating
                            ? 'Generando...'
                            : _weeklyRoster != null
                                ? 'Regenerar Rol Automático'
                                : 'Generar Rol Automático',
                      ),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.all(16),
                        backgroundColor: AppTheme.navyBlue,
                      ),
                    ),
                  ),

                  if (_weeklyRoster != null) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: _weeklyRoster!.isPublished
                            ? AppTheme.efectivaColor.withOpacity(0.1)
                            : AppTheme.warningColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _weeklyRoster!.isPublished
                                ? Icons.check_circle
                                : Icons.edit,
                            size: 16,
                            color: _weeklyRoster!.isPublished
                                ? AppTheme.efectivaColor
                                : AppTheme.warningColor,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            _weeklyRoster!.isPublished
                                ? 'Publicado'
                                : 'Borrador',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: _weeklyRoster!.isPublished
                                  ? AppTheme.efectivaColor
                                  : AppTheme.warningColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          // Roster preview
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _weeklyRoster == null
                    ? _buildEmptyState()
                    : _dailyRosters.isEmpty
                        ? _buildNoAssignmentsState()
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: _dailyRosters.length,
                            itemBuilder: (context, index) {
                              final roster = _dailyRosters[index];
                              return GuardRosterCard(roster: roster);
                            },
                          ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.auto_awesome,
              size: 64,
              color: AppTheme.navyBlue.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'Generar Rol Semanal',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.grey.shade700,
                    fontWeight: FontWeight.bold,
                  ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'Presione el botón para generar automáticamente el rol basado en la disponibilidad registrada',
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoAssignmentsState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.event_busy,
              size: 64,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 16),
            Text(
              'Sin asignaciones',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.grey.shade600,
                  ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'No hay suficiente disponibilidad registrada para generar el rol',
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
