import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:sexta_app/core/theme/app_theme.dart';
import 'package:sexta_app/models/guard_roster_model.dart';
import 'package:sexta_app/models/user_model.dart';
import 'package:sexta_app/providers/user_provider.dart';
import 'package:sexta_app/services/guard_roster_service.dart';
import 'package:sexta_app/widgets/app_drawer.dart';
import 'package:sexta_app/widgets/guard_calendar_picker.dart';

/// Screen for users to register their availability for night guards
class GuardAvailabilityScreen extends ConsumerStatefulWidget {
  const GuardAvailabilityScreen({super.key});

  @override
  ConsumerState<GuardAvailabilityScreen> createState() =>
      _GuardAvailabilityScreenState();
}

class _GuardAvailabilityScreenState
    extends ConsumerState<GuardAvailabilityScreen> {
  final _guardRosterService = GuardRosterService();
  
  List<DateTime> _selectedDates = [];
  bool _registerAsDriver = false;
  bool _isLoading = false;
  bool _isSaving = false;
  
  List<GuardAvailability> _existingAvailability = [];
  UserModel? _currentUser;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    try {
      _currentUser = ref.read(currentUserProvider);
      
      if (_currentUser != null) {
        // Load user's existing availability (next 60 days)
        final startDate = DateTime.now();
        final availability = await _guardRosterService.getUserAvailability(
          _currentUser!.id,
          startDate: startDate,
        );
        
        setState(() {
          _existingAvailability = availability;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al cargar disponibilidad: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveAvailability() async {
    if (_selectedDates.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seleccione al menos una fecha')),
      );
      return;
    }

    if (_currentUser == null) return;

    setState(() => _isSaving = true);

    try {
      // Register each selected date
      for (final date in _selectedDates) {
        await _guardRosterService.registerAvailability(
          userId: _currentUser!.id,
          date: date,
          isDriver: _registerAsDriver,
        );
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Disponibilidad registrada: ${_selectedDates.length} fecha(s)',
            ),
            backgroundColor: AppTheme.efectivaColor,
          ),
        );
      }

      // Reload data and clear selection
      setState(() {
        _selectedDates = [];
        _registerAsDriver = false;
      });
      
      await _loadData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al guardar: $e')),
        );
      }
    } finally {
      setState(() => _isSaving = false);
    }
  }

  Future<void> _deleteAvailability(GuardAvailability availability) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar eliminación'),
        content: Text(
          '¿Eliminar disponibilidad del ${DateFormat('dd/MM/yyyy').format(availability.availableDate)}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await _guardRosterService.removeAvailability(availability.id);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Disponibilidad eliminada'),
            backgroundColor: AppTheme.warningColor,
          ),
        );
      }
      
      await _loadData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al eliminar: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inscribir Disponibilidad'),
      ),
      drawer: const AppDrawer(),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Instructions
                  Card(
                    color: AppTheme.navyBlue.withOpacity(0.1),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.info_outline, color: AppTheme.navyBlue),
                              const SizedBox(width: 8),
                              Text(
                                'Instrucciones',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                      color: AppTheme.navyBlue,
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            '1. Seleccione las fechas en las que está disponible para guardia nocturna\n'
                            '2. Marque "Maquinista" si puede cumplir ese rol\n'
                            '3. Presione "Guardar Disponibilidad"\n'
                            '4. Puede eliminar inscripciones desde la lista inferior',
                            style: TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Calendar picker
                  Text(
                    'Seleccionar Fechas',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 16),
                  
                  GuardCalendarPicker(
                    selectedDates: _selectedDates,
                    onDatesChanged: (dates) {
                      setState(() => _selectedDates = dates);
                    },
                    minDate: DateTime.now(),
                    maxDate: DateTime.now().add(const Duration(days: 90)),
                  ),
                  const SizedBox(height: 24),

                  // Driver checkbox
                  CheckboxListTile(
                    value: _registerAsDriver,
                    onChanged: (value) {
                      setState(() => _registerAsDriver = value ?? false);
                    },
                    title: const Text('Me inscribo como Maquinista'),
                    subtitle: const Text(
                      'Marque esta opción si puede cumplir el rol de maquinista',
                    ),
                    activeColor: AppTheme.navyBlue,
                  ),
                  const SizedBox(height: 24),

                  // Save button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _isSaving || _selectedDates.isEmpty
                          ? null
                          : _saveAvailability,
                      icon: _isSaving
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.save),
                      label: Text(
                        _isSaving
                            ? 'Guardando...'
                            : 'Guardar Disponibilidad (${_selectedDates.length})',
                      ),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.all(16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Existing availability list
                  Row(
                    children: [
                      Text(
                        'Mis Inscripciones',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const Spacer(),
                      Text(
                        '${_existingAvailability.length} fecha(s)',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppTheme.navyBlue,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  if (_existingAvailability.isEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(32),
                        child: Center(
                          child: Column(
                            children: [
                              Icon(
                                Icons.event_busy,
                                size: 48,
                                color: Colors.grey.shade400,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'No hay inscripciones registradas',
                                style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                  else
                    ..._existingAvailability.map((availability) {
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: AppTheme.navyBlue.withOpacity(0.1),
                            child: Icon(
                              availability.isDriver
                                  ? Icons.local_shipping
                                  : Icons.person,
                              color: AppTheme.navyBlue,
                            ),
                          ),
                          title: Text(
                            DateFormat('EEEE, dd MMMM yyyy', 'es_ES')
                                .format(availability.availableDate),
                          ),
                          subtitle: Text(
                            availability.isDriver
                                ? 'Inscrito como Maquinista'
                                : 'Inscrito como Bombero',
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteAvailability(availability),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }
}
