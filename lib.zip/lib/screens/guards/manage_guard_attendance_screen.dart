import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sexta_app/models/guard_attendance_model.dart';
import 'package:sexta_app/models/user_model.dart';
import 'package:sexta_app/services/guard_attendance_service.dart';
import 'package:sexta_app/services/supabase_service.dart';

/// Administrative screen for managing all guard attendances
/// Allows viewing, editing, and deleting all guard records without time restrictions
class ManageGuardAttendanceScreen extends StatefulWidget {
  const ManageGuardAttendanceScreen({Key? key}) : super(key: key);

  @override
  State<ManageGuardAttendanceScreen> createState() => _ManageGuardAttendanceScreenState();
}

class _ManageGuardAttendanceScreenState extends State<ManageGuardAttendanceScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _guardService = GuardAttendanceService();

  // State for each tab
  bool _isLoadingFds = false;
  bool _isLoadingDiurna = false;
  bool _isLoadingNocturna = false;

  List<GuardAttendanceFds> _fdsRecords = [];
  List<GuardAttendanceDiurna> _diurnaRecords = [];
  List<GuardAttendanceNocturna> _nocturnaRecords = [];

  // Filters
  DateTime? _filterStartDate;
  DateTime? _filterEndDate;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadAllData();
  }

  Future<void> _loadAllData() async {
    await Future.wait([
      _loadFdsRecords(),
      _loadDiurnaRecords(),
      _loadNocturnaRecords(),
    ]);
  }

  Future<void> _loadFdsRecords() async {
    setState(() => _isLoadingFds = true);
    try {
      final records = await _guardService.getFdsAttendanceHistory(limit: 50);
      setState(() {
        _fdsRecords = records;
        _isLoadingFds = false;
      });
    } catch (e) {
      setState(() => _isLoadingFds = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al cargar FDS: $e')),
        );
      }
    }
  }

  Future<void> _loadDiurnaRecords() async {
    setState(() => _isLoadingDiurna = true);
    try {
      final records = await _guardService.getDiurnaAttendanceHistory(limit: 50);
      setState(() {
        _diurnaRecords = records;
        _isLoadingDiurna = false;
      });
    } catch (e) {
      setState(() => _isLoadingDiurna = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al cargar Diurna: $e')),
        );
      }
    }
  }

  Future<void> _loadNocturnaRecords() async {
    setState(() => _isLoadingNocturna = true);
    try {
      final records = await _guardService.getNocturnaAttendanceHistory(limit: 50);
      setState(() {
        _nocturnaRecords = records;
        _isLoadingNocturna = false;
      });
    } catch (e) {
      setState(() => _isLoadingNocturna = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al cargar Nocturna: $e')),
        );
      }
    }
  }

  Future<void> _deleteFdsRecord(String id) async {
    final confirmed = await _showDeleteConfirmation();
    if (!confirmed) return;

    try {
      await _guardService.deleteFdsAttendance(id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Registro eliminado'),
          backgroundColor: Colors.green,
        ),
      );
      _loadFdsRecords();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _deleteDiurnaRecord(String id) async {
    final confirmed = await _showDeleteConfirmation();
    if (!confirmed) return;

    try {
      await _guardService.deleteDiurnaAttendance(id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Registro eliminado'),
          backgroundColor: Colors.green,
        ),
      );
      _loadDiurnaRecords();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _deleteNocturnaRecord(String id) async {
    final confirmed = await _showDeleteConfirmation();
    if (!confirmed) return;

    try {
      await _guardService.deleteNocturnaAttendance(id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Registro eliminado'),
          backgroundColor: Colors.green,
        ),
      );
      _loadNocturnaRecords();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<bool> _showDeleteConfirmation() async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Confirmar eliminación'),
            content: const Text(
              '¿Estás seguro de que deseas eliminar este registro?\n\nEsta acción no se puede deshacer.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancelar'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, true),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text('Eliminar'),
              ),
            ],
          ),
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestión de Guardias'),
        backgroundColor: Colors.deepPurple,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.wb_sunny), text: 'FDS'),
            Tab(icon: Icon(Icons.light_mode), text: 'Diurna'),
            Tab(icon: Icon(Icons.nightlight_round), text: 'Nocturna'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadAllData,
            tooltip: 'Recargar',
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildFdsTab(),
          _buildDiurnaTab(),
          _buildNocturnaTab(),
        ],
      ),
    );
  }

  Widget _buildFdsTab() {
    if (_isLoadingFds) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_fdsRecords.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No hay registros de guardias FDS'),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadFdsRecords,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _fdsRecords.length,
        itemBuilder: (context, index) {
          final record = _fdsRecords[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ExpansionTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blue,
                child: Text(
                  record.shiftPeriod,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              title: Text(
                DateFormat('EEEE, dd/MM/yyyy', 'es_ES').format(record.guardDate),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '${record.assignedCount} personas • Creado: ${DateFormat('dd/MM HH:mm').format(record.createdAt)}',
              ),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (record.observations != null) ...[
                        const Text(
                          'Observaciones:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(record.observations!),
                        const SizedBox(height: 16),
                      ],
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton.icon(
                            onPressed: () => _editFdsRecord(record),
                            icon: const Icon(Icons.edit, color: Colors.blue),
                            label: const Text(
                              'Editar',
                              style: TextStyle(color: Colors.blue),
                            ),
                          ),
                          const SizedBox(width: 8),
                          TextButton.icon(
                            onPressed: () => _deleteFdsRecord(record.id),
                            icon: const Icon(Icons.delete, color: Colors.red),
                            label: const Text(
                              'Eliminar',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDiurnaTab() {
    if (_isLoadingDiurna) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_diurnaRecords.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No hay registros de guardias Diurnas'),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadDiurnaRecords,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _diurnaRecords.length,
        itemBuilder: (context, index) {
          final record = _diurnaRecords[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ExpansionTile(
              leading: CircleAvatar(
                backgroundColor: Colors.orange,
                child: Text(
                  record.shiftPeriod,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              title: Text(
                DateFormat('EEEE, dd/MM/yyyy', 'es_ES').format(record.guardDate),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '${record.assignedCount} personas • Creado: ${DateFormat('dd/MM HH:mm').format(record.createdAt)}',
              ),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (record.observations != null) ...[
                        const Text(
                          'Observaciones:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(record.observations!),
                        const SizedBox(height: 16),
                      ],
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton.icon(
                            onPressed: () => _editDiurnaRecord(record),
                            icon: const Icon(Icons.edit, color: Colors.blue),
                            label: const Text(
                              'Editar',
                              style: TextStyle(color: Colors.blue),
                            ),
                          ),
                          const SizedBox(width: 8),
                          TextButton.icon(
                            onPressed: () => _deleteDiurnaRecord(record.id),
                            icon: const Icon(Icons.delete, color: Colors.red),
                            label: const Text(
                              'Eliminar',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildNocturnaTab() {
    if (_isLoadingNocturna) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_nocturnaRecords.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No hay registros de guardias Nocturnas'),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadNocturnaRecords,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _nocturnaRecords.length,
        itemBuilder: (context, index) {
          final record = _nocturnaRecords[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ExpansionTile(
              leading: const CircleAvatar(
                backgroundColor: Colors.indigo,
                child: Icon(Icons.nightlight_round, color: Colors.white),
              ),
              title: Text(
                DateFormat('EEEE, dd/MM/yyyy', 'es_ES').format(record.guardDate),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '${record.assignedCount} personas • Creado: ${DateFormat('dd/MM HH:mm').format(record.createdAt)}',
              ),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (record.observations != null) ...[
                        const Text(
                          'Observaciones:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(record.observations!),
                        const SizedBox(height: 16),
                      ],
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton.icon(
                            onPressed: () => _editNocturnaRecord(record),
                            icon: const Icon(Icons.edit, color: Colors.blue),
                            label: const Text(
                              'Editar',
                              style: TextStyle(color: Colors.blue),
                            ),
                          ),
                          const SizedBox(width: 8),
                          TextButton.icon(
                            onPressed: () => _deleteNocturnaRecord(record.id),
                            icon: const Icon(Icons.delete, color: Colors.red),
                            label: const Text(
                              'Eliminar',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ============================================================================
  // EDIT METHODS
  // ============================================================================

  Future<void> _editFdsRecord(GuardAttendanceFds record) async {
    final observationsController = TextEditingController(text: record.observations);

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar Guardia FDS'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Fecha: ${DateFormat('dd/MM/yyyy').format(record.guardDate)}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              Text('Período: ${record.shiftPeriod}'),
              const SizedBox(height: 16),
              TextField(
                controller: observationsController,
                decoration: const InputDecoration(
                  labelText: 'Observaciones',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              const Text(
                'Nota: Para editar personal, use la pantalla de registro',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Guardar'),
          ),
        ],
      ),
    );

    if (result == true) {
      try {
        await _guardService.updateFdsAttendance(
          record.id,
          {'observations': observationsController.text.trim().isEmpty ? null : observationsController.text.trim()},
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Registro actualizado'), backgroundColor: Colors.green),
        );
        _loadFdsRecords();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }

    observationsController.dispose();
  }

  Future<void> _editDiurnaRecord(GuardAttendanceDiurna record) async {
    final observationsController = TextEditingController(text: record.observations);

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar Guardia Diurna'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Fecha: ${DateFormat('dd/MM/yyyy').format(record.guardDate)}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              Text('Período: ${record.shiftPeriod}'),
              const SizedBox(height: 16),
              TextField(
                controller: observationsController,
                decoration: const InputDecoration(
                  labelText: 'Observaciones',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              const Text(
                'Nota: Para editar personal, use la pantalla de registro',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Guardar'),
          ),
        ],
      ),
    );

    if (result == true) {
      try {
        await _guardService.updateDiurnaAttendance(
          record.id,
          {'observations': observationsController.text.trim().isEmpty ? null : observationsController.text.trim()},
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Registro actualizado'), backgroundColor: Colors.green),
        );
        _loadDiurnaRecords();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }

    observationsController.dispose();
  }

  Future<void> _editNocturnaRecord(GuardAttendanceNocturna record) async {
    final observationsController = TextEditingController(text: record.observations);

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar Guardia Nocturna'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Fecha: ${DateFormat('dd/MM/yyyy').format(record.guardDate)}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: observationsController,
                decoration: const InputDecoration(
                  labelText: 'Observaciones',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              const Text(
                'Nota: Para editar asistencias, use la pantalla de registro',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Guardar'),
          ),
        ],
      ),
    );

    if (result == true) {
      try {
        await _guardService.updateNocturnaAttendance(
          record.id,
          {'observations': observationsController.text.trim().isEmpty ? null : observationsController.text.trim()},
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Registro actualizado'), backgroundColor: Colors.green),
        );
        _loadNocturnaRecords();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }

    observationsController.dispose();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}
