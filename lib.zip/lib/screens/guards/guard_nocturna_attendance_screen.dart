import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sexta_app/core/constants/app_constants.dart';
import 'package:sexta_app/models/guard_attendance_model.dart';
import 'package:sexta_app/models/guard_roster_model.dart';
import 'package:sexta_app/models/user_model.dart';
import 'package:sexta_app/services/guard_attendance_service.dart';
import 'package:sexta_app/services/guard_roster_service.dart';
import 'package:sexta_app/services/supabase_service.dart';
import 'package:sexta_app/widgets/app_drawer.dart';
import 'package:sexta_app/widgets/searchable_user_selector.dart';

/// Screen for registering Nocturna (Night) guard attendance
/// ROSTER-BASED: Loads personnel from published roster
/// Time: 23:00 to 08:00 (next day)
/// Date Selection: Today or Yesterday only
class GuardNocturnaAttendanceScreen extends StatefulWidget {
  const GuardNocturnaAttendanceScreen({Key? key}) : super(key: key);

  @override
  State<GuardNocturnaAttendanceScreen> createState() =>
      _GuardNocturnaAttendanceScreenState();
}

enum DateOption { today, yesterday }

enum AttendanceStatus { present, absent, permission, replaced }

class PersonnelAttendance {
  final UserModel user;
  final String role; // 'Maquinista', 'OBAC', 'Bombero'
  AttendanceStatus status;
  UserModel? replacement;

  PersonnelAttendance({
    required this.user,
    required this.role,
    this.status = AttendanceStatus.present,
    this.replacement,
  });
}

class _GuardNocturnaAttendanceScreenState
    extends State<GuardNocturnaAttendanceScreen> {
  final _formKey = GlobalKey<FormState>();
  final _guardService = GuardAttendanceService();
  final _rosterService = GuardRosterService();
  final _supabaseService = SupabaseService();
  final TextEditingController _observationsController = TextEditingController();

  // State
  bool _isLoading = false;
  bool _isLoadingRoster = false;
  DateOption _selectedDateOption = DateOption.today;
  DateTime? _guardDate;
  GuardRosterDaily? _roster;
  List<PersonnelAttendance> _personnel = [];
  List<UserModel> _allUsers = [];
  List<GuardAttendanceNocturna> _history = [];
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _initializeDate();
    _loadUsers();
    _loadHistory();
  }

  Future<void> _loadUsers() async {
    try {
      final users = await _supabaseService.getAllUsers();
      setState(() => _allUsers = users);
    } catch (e) {
      print('Error loading users: $e');
    }
  }

  void _initializeDate() {
    final now = DateTime.now();
    // If before 08:00 AM, default to yesterday
    if (now.hour < 8) {
      _selectedDateOption = DateOption.yesterday;
    } else {
      _selectedDateOption = DateOption.today;
    }
    _updateGuardDate();
  }

  void _updateGuardDate() {
    final now = DateTime.now();
    if (_selectedDateOption == DateOption.today) {
      _guardDate = DateTime(now.year, now.month, now.day);
    } else {
      final yesterday = now.subtract(const Duration(days: 1));
      _guardDate = DateTime(yesterday.year, yesterday.month, yesterday.day);
    }
    _loadRoster();
  }

  Future<void> _loadRoster() async {
    if (_guardDate == null) return;

    setState(() {
      _isLoadingRoster = true;
      _errorMessage = null;
      _personnel = [];
    });

    try {
      // Check if attendance already registered
      final alreadyRegistered = await _guardService.isGuardAlreadyRegistered(
        AppConstants.guardAttendanceNocturnaTable,
        _guardDate!,
        null,
      );

      if (alreadyRegistered) {
        setState(() {
          _errorMessage = 'Guardia ya registrada para esta fecha';
          _isLoadingRoster = false;
        });
        return;
      }

      // Load published roster
      final roster = await _rosterService.getPublishedDailyRosterForDate(_guardDate!);

      if (roster == null) {
        setState(() {
          _errorMessage = 'No hay rol de guardia publicado para esta fecha';
          _isLoadingRoster = false;
        });
        return;
      }

      // Build personnel list
      final personnel = <PersonnelAttendance>[];

      if (roster.maquinista != null) {
        personnel.add(PersonnelAttendance(
          user: roster.maquinista!,
          role: 'Maquinista',
        ));
      }

      if (roster.obac != null) {
        personnel.add(PersonnelAttendance(
          user: roster.obac!,
          role: 'OBAC',
        ));
      }

      if (roster.bomberos != null) {
        for (var bombero in roster.bomberos!) {
          personnel.add(PersonnelAttendance(
            user: bombero,
            role: 'Bombero',
          ));
        }
      }

      setState(() {
        _roster = roster;
        _personnel = personnel;
        _isLoadingRoster = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Error al cargar el rol: $e';
        _isLoadingRoster = false;
      });
    }
  }

  Future<void> _loadHistory() async {
    try {
      final history = await _guardService.getNocturnaAttendanceHistory(limit: 10);
      setState(() => _history = history);
    } catch (e) {
      print('Error loading history: $e');
    }
  }

  Future<void> _saveAttendance() async {
    if (!_formKey.currentState!.validate()) return;

    // Validate all personnel have status
    final allMarked = _personnel.every((p) => true); // All have default status

    if (!allMarked) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Debe marcar el estado de todo el personal'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Build records
      final records = <GuardAttendanceRecord>[];
      
      for (var person in _personnel) {
        String statusStr;
        switch (person.status) {
          case AttendanceStatus.present:
            statusStr = 'present';
            break;
          case AttendanceStatus.absent:
            statusStr = 'absent';
            break;
          case AttendanceStatus.permission:
            statusStr = 'permission';
            break;
          case AttendanceStatus.replaced:
            statusStr = 'replaced';
            break;
        }
        
        // TODO: Implement proper attendance record tracking
        // GuardAttendanceRecord requires database-generated fields (id, guardAttendanceId, createdAt)
        // For now, attendance is tracked through the main guard attendance table
      }


      await _guardService.createNocturnaAttendance(
        guardDate: _guardDate!,
        rosterWeekId: _roster!.rosterWeekId,
        maquinistaId: _roster!.maquinistaId,
        obacId: _roster!.obacId,
        bomberoIds: _roster!.bomberoIds.cast<String?>(),
        records: null, // TODO: Implement detailed attendance tracking
        observations: _observationsController.text.trim().isEmpty
            ? null
            : _observationsController.text.trim(),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Asistencia guardada exitosamente'),
            backgroundColor: Colors.green,
          ),
        );

        // Reset and reload
        _resetForm();
        _loadHistory();
        _loadRoster(); // Reload to show "already registered" message
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _resetForm() {
    setState(() {
      _observationsController.clear();
      _personnel = [];
      _roster = null;
    });
  }

  Future<void> _selectReplacement(int index) async {
    // Load all users if not loaded
    if (_allUsers.isEmpty) {
      // TODO: Load from supabase service
    }

    final selected = await showDialog<UserModel>(
      context: context,
      builder: (context) => _ReplacementDialog(
        availableUsers: _allUsers,
        currentPerson: _personnel[index].user,
      ),
    );

    if (selected != null) {
      setState(() {
        _personnel[index].replacement = selected;
        _personnel[index].status = AttendanceStatus.replaced;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Asist. a Guardia Nocturna'),
        backgroundColor: Colors.indigo,
      ),
      drawer: const AppDrawer(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Info card
            Card(
              color: Colors.indigo.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.indigo.shade700),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Guardias nocturnas basadas en el rol publicado\\nHorario: 23:00 - 08:00 hrs',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.indigo.shade900,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Date selection (Today/Yesterday)
            const Text(
              'Seleccionar Fecha',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: RadioListTile<DateOption>(
                    title: const Text('Hoy'),
                    subtitle: Text(
                      DateFormat('dd/MM/yyyy').format(DateTime.now()),
                      style: const TextStyle(fontSize: 12),
                    ),
                    value: DateOption.today,
                    groupValue: _selectedDateOption,
                    onChanged: (value) {
                      setState(() => _selectedDateOption = value!);
                      _updateGuardDate();
                    },
                  ),
                ),
                Expanded(
                  child: RadioListTile<DateOption>(
                    title: const Text('Ayer'),
                    subtitle: Text(
                      DateFormat('dd/MM/yyyy').format(
                        DateTime.now().subtract(const Duration(days: 1)),
                      ),
                      style: const TextStyle(fontSize: 12),
                    ),
                    value: DateOption.yesterday,
                    groupValue: _selectedDateOption,
                    onChanged: (value) {
                      setState(() => _selectedDateOption = value!);
                      _updateGuardDate();
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 16),

            // Roster content
            if (_isLoadingRoster)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: CircularProgressIndicator(),
                ),
              )
            else if (_errorMessage != null)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    children: [
                      Icon(
                        Icons.warning_amber_rounded,
                        size: 64,
                        color: Colors.orange.shade400,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        _errorMessage!,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey.shade700,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            else if (_personnel.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Text('No hay personal asignado en el rol'),
                ),
              )
            else
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Personal Asignado (${_personnel.length})',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Personnel list
                    ...List.generate(_personnel.length, (index) {
                      return _buildPersonnelCard(index);
                    }),

                    const SizedBox(height: 24),

                    // Observations
                    TextField(
                      controller: _observationsController,
                      decoration: const InputDecoration(
                        labelText: 'Observaciones (opcional)',
                        border: OutlineInputBorder(),
                        hintText: 'Notas adicionales...',
                      ),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 24),

                    // Save button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _saveAttendance,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.indigo,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Text(
                                'Guardar Asistencia',
                                style: TextStyle(fontSize: 16),
                              ),
                      ),
                    ),
                  ],
                ),
              ),

            const SizedBox(height: 32),

            // History section
            const Divider(),
            const SizedBox(height: 16),
            const Text(
              'Historial Reciente',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),

            _history.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text('No hay registros'),
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _history.length,
                    itemBuilder: (context, index) {
                      final record = _history[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.indigo,
                            child: const Icon(
                              Icons.nightlight_round,
                              color: Colors.white,
                            ),
                          ),
                          title: Text(
                            DateFormat('dd/MM/yyyy').format(record.guardDate),
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            '${record.assignedCount} personas asignadas',
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            // TODO: Navigate to detail/edit screen
                          },
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonnelCard(int index) {
    final person = _personnel[index];
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.indigo.shade100,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    person.role,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.indigo.shade900,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    person.user.fullName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Status selection
            Wrap(
              spacing: 8,
              children: [
                _buildStatusChip(
                  index,
                  AttendanceStatus.present,
                  '✅ Presente',
                  Colors.green,
                ),
                _buildStatusChip(
                  index,
                  AttendanceStatus.absent,
                  '❌ Ausente',
                  Colors.red,
                ),
                _buildStatusChip(
                  index,
                  AttendanceStatus.permission,
                  '📋 Permiso',
                  Colors.orange,
                ),
                _buildStatusChip(
                  index,
                  AttendanceStatus.replaced,
                  '🔄 Reemplazado',
                  Colors.blue,
                ),
              ],
            ),

            // Replacement info
            if (person.status == AttendanceStatus.replaced) ...[
              const SizedBox(height: 12),
              if (person.replacement != null)
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: Colors.blue.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.arrow_forward, size: 16, color: Colors.blue.shade700),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Reemplazado por: ${person.replacement!.fullName}',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.blue.shade900,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.edit, size: 18),
                        onPressed: () => _selectReplacement(index),
                      ),
                    ],
                  ),
                )
              else
                ElevatedButton.icon(
                  onPressed: () => _selectReplacement(index),
                  icon: const Icon(Icons.person_add, size: 18),
                  label: const Text('Seleccionar reemplazo'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatusChip(
    int index,
    AttendanceStatus status,
    String label,
    Color color,
  ) {
    final isSelected = _personnel[index].status == status;

    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (selected) {
        setState(() {
          _personnel[index].status = status;
          if (status != AttendanceStatus.replaced) {
            _personnel[index].replacement = null;
          }
        });
      },
      selectedColor: color.withOpacity(0.3),
      checkmarkColor: Colors.grey.shade900,
      labelStyle: TextStyle(
        color: isSelected ? Colors.grey.shade900 : Colors.grey.shade700,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
    );
  }

  @override
  void dispose() {
    _observationsController.dispose();
    super.dispose();
  }
}

/// Dialog for selecting a replacement
class _ReplacementDialog extends StatefulWidget {
  final List<UserModel> availableUsers;
  final UserModel currentPerson;

  const _ReplacementDialog({
    required this.availableUsers,
    required this.currentPerson,
  });

  @override
  State<_ReplacementDialog> createState() => _ReplacementDialogState();
}

class _ReplacementDialogState extends State<_ReplacementDialog> {
  final TextEditingController _searchController = TextEditingController();
  List<UserModel> _filteredUsers = [];

  @override
  void initState() {
    super.initState();
    _filteredUsers = widget.availableUsers;
    _searchController.addListener(_filterUsers);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _filterUsers() {
    final query = _searchController.text.toLowerCase().trim();

    setState(() {
      if (query.isEmpty) {
        _filteredUsers = widget.availableUsers;
      } else {
        _filteredUsers = widget.availableUsers.where((user) {
          final fullName = user.fullName.toLowerCase();
          return fullName.contains(query);
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.6,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Seleccionar Reemplazo',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _searchController,
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'Buscar por nombre...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),

            Expanded(
              child: ListView.builder(
                itemCount: _filteredUsers.length,
                itemBuilder: (context, index) {
                  final user = _filteredUsers[index];
                  return ListTile(
                    leading: CircleAvatar(
                      child: Text(user.firstName[0].toUpperCase()),
                    ),
                    title: Text(user.fullName),
                    subtitle: Text(user.rank),
                    onTap: () => Navigator.pop(context, user),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
