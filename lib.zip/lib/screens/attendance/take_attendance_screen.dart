import 'package:flutter/material.dart';
import 'package:sexta_app/core/theme/app_theme.dart';
import 'package:sexta_app/widgets/app_drawer.dart';
import 'package:sexta_app/widgets/branded_app_bar.dart';
import 'package:sexta_app/services/supabase_service.dart';
import 'package:sexta_app/services/simple_auth_service.dart';
import 'package:sexta_app/services/attendance_service.dart';
import 'package:sexta_app/models/user_model.dart';
import 'package:sexta_app/models/attendance_record_model.dart';
import 'package:intl/intl.dart';

/// Módulo 3: Toma de Asistencia con Auto-Crosscheck de Licencias
class TakeAttendanceScreen extends StatefulWidget {
  const TakeAttendanceScreen({super.key});

  @override
  State<TakeAttendanceScreen> createState() => _TakeAttendanceScreenState();
}

class _TakeAttendanceScreenState extends State<TakeAttendanceScreen> {
  final _supabase = SupabaseService();
  final _authService = SimpleAuthService();
  final _attendanceService = AttendanceService();
  
  DateTime _selectedDate = DateTime.now();
  String? _selectedActTypeId;
  List<Map<String, dynamic>> _actTypes = [];
  List<Map<String, dynamic>> _attendanceList = [];
  bool _isLoading = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _loadActTypes();
  }

  Future<void> _loadActTypes() async {
    try {
      final actTypes = await _supabase.getAllActTypes();
      print('✅ Act types loaded: ${actTypes.length} tipos'); // DEBUG
      print('Act types: $actTypes'); // DEBUG
      setState(() => _actTypes = actTypes);
    } catch (e) {
      print('❌ Error loading act types: $e'); // DEBUG
      _showError('Error cargando tipos de acto: $e');
    }
  }

  Future<void> _loadAttendanceList() async {
    if (_selectedActTypeId == null) {
      _showError('Por favor seleccione un tipo de acto');
      return;
    }

    setState(() => _isLoading = true);

    try {
      // 1. Cargar todos los usuarios
      final users = await _supabase.getAllUsers();
      
      // 2. LÓGICA CRÍTICA: Preparar lista con auto-check de licencias
      final attendanceList = await _attendanceService.prepareAttendanceList(
        users,
        _selectedDate,
      );

      setState(() {
        _attendanceList = attendanceList;
        _isLoading = false;
      });

      // Mostrar info de usuarios con licencia
      final licensedCount = attendanceList.where((u) => u['hasLicense'] == true).length;
      if (licensedCount > 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$licensedCount bombero(s) tienen licencia aprobada para esta fecha'),
            backgroundColor: AppTheme.abonoColor,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _showError('Error cargando lista: $e');
    }
  }

  Future<void> _saveAttendance() async {
    if (_attendanceList.isEmpty) {
      _showError('Primero cargue la lista de asistencia');
      return;
    }

    setState(() => _isSaving = true);

    try {
      final userId = _authService.currentUserId;
      if (userId == null) throw Exception('Usuario no autenticado');

      // Preparar registros de asistencia
      final records = _attendanceList.map((item) {
        final user = item['user'] as UserModel;
        return {
          'userId': user.id,
          'status': (item['status'] as AttendanceStatus).name,
          'isLocked': item['isLocked'] as bool,
        };
      }).toList();

      // Crear evento y registros
      await _attendanceService.createAttendanceEvent(
        actTypeId: _selectedActTypeId!,
        eventDate: _selectedDate,
        createdBy: userId,
        attendanceRecords: records,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Asistencia guardada exitosamente'),
            backgroundColor: AppTheme.efectivaColor,
          ),
        );

        // Limpiar formulario
        setState(() {
          _attendanceList = [];
          _selectedActTypeId = null;
        });
      }
    } catch (e) {
      _showError('Error guardando asistencia: $e');
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  void _toggleAttendance(int index) {
    final item = _attendanceList[index];
    
    // No permitir editar si está bloqueado por licencia
    if (item['isLocked'] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Este registro está bloqueado por licencia aprobada'),
          backgroundColor: AppTheme.warningColor,
        ),
      );
      return;
    }

    setState(() {
      final currentStatus = item['status'] as AttendanceStatus;
      _attendanceList[index]['status'] = currentStatus == AttendanceStatus.present
          ? AttendanceStatus.absent
          : AttendanceStatus.present;
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: AppTheme.criticalColor),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tomar Asistencia'),
        actions: [
          if (_attendanceList.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.save),
              onPressed: _isSaving ? null : _saveAttendance,
            ),
        ],
      ),
      drawer: const AppDrawer(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Configuración del evento
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Configuración del Evento',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 20),
                    
                    // Fecha
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Fecha del Evento',
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                              const SizedBox(height: 8),
                              InkWell(
                                onTap: () async {
                                  final date = await showDatePicker(
                                    context: context,
                                    initialDate: _selectedDate,
                                    firstDate: DateTime.now().subtract(const Duration(days: 30)),
                                    lastDate: DateTime.now(),
                                  );
                                  if (date != null) {
                                    setState(() {
                                      _selectedDate = date;
                                      _attendanceList = []; // Reset lista si cambia fecha
                                    });
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.calendar_today, size: 20),
                                      const SizedBox(width: 12),
                                      Text(DateFormat('dd/MM/yyyy').format(_selectedDate)),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    
                    // Tipo de Acto
                    Text(
                      'Tipo de Acto',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: _selectedActTypeId,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Seleccione tipo de acto',
                      ),
                      items: _actTypes.map((actType) {
                        final category = actType['category'] as String;
                        final color = category == 'efectiva' 
                            ? AppTheme.efectivaColor 
                            : AppTheme.abonoColor;
                        
                        return DropdownMenuItem(
                          value: actType['id'] as String,
                          child: Row(
                            children: [
                              Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: color,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Text(actType['name'] as String),
                            ],
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedActTypeId = value;
                          _attendanceList = []; // Reset lista si cambia tipo
                        });
                      },
                    ),
                    const SizedBox(height: 20),
                    
                    // Botón cargar lista
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _isLoading ? null : _loadAttendanceList,
                        icon: _isLoading 
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.people),
                        label: Text(_isLoading ? 'Cargando...' : 'Cargar Lista de Asistencia'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Lista de asistencia AGRUPADA POR CATEGORÍA
            if (_attendanceList.isNotEmpty) ...[
              const SizedBox(height: 24),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Lista de Asistencia',
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          const Spacer(),
                          Text(
                            '${_attendanceList.where((u) => u['status'] == AttendanceStatus.present).length}/${_attendanceList.length} presentes',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: AppTheme.efectivaColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      
                      // Leyenda
                      Wrap(
                        spacing: 16,
                        children: [
                          _buildLegend(Icons.check_circle, 'Presente', AppTheme.efectivaColor),
                          _buildLegend(Icons.cancel, 'Ausente', Colors.grey),
                          _buildLegend(Icons.lock, 'Licencia (Bloqueado)', AppTheme.warningColor),
                        ],
                      ),
                      const SizedBox(height: 20),
                      
                      // GRUPOS POR CATEGORÍA
                      ..._buildGroupedAttendanceList(),
                      
                      const SizedBox(height: 20),
                      
                      // Botón guardar
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _isSaving ? null : _saveAttendance,
                          icon: _isSaving
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.save),
                          label: Text(_isSaving ? 'Guardando...' : 'Guardar Asistencia'),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.all(16),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Agrupa asistencia por categoría de cargo
  List<Widget> _buildGroupedAttendanceList() {
    // Categorías de cargos (actualizadas)
    final categories = {
      'OFICIALES DE COMPAÑÍA': ['Director', 'Secretari', 'Tesorer', 'Capitán', 'Teniente', 'Ayudante'],
      'OFICIALES DE CUERPO': ['Of. General', 'Inspector', 'Ayudante de Comandancia'],
      'MIEMBROS HONORARIOS': ['Honorario'],
      'VOLUNTARIOS ACTIVOS': ['Bombero'],
      'ASPIRANTES Y POSTULANTES': ['Aspirante', 'Postulante'],
    };

    List<Widget> groups = [];

    for (var entry in categories.entries) {
      final categoryName = entry.key;
      final cargosInCategory = entry.value;
      
      // Filtrar usuarios de esta categoría
      final usersInCategory = _attendanceList.where((item) {
        final user = item['user'] as UserModel;
        final rankLower = user.rank.toLowerCase();
        
        // Lógica especial para Voluntarios Activos: 
        // Incluir si contiene "Bombero", pero EXCLUIR Honorarios y Oficiales
        if (categoryName == 'VOLUNTARIOS ACTIVOS') {
          final isHonorary = rankLower.contains('honorario');
          final isOfficer = rankLower.contains('director') || 
                           rankLower.contains('secretari') || 
                           rankLower.contains('tesorer') ||
                           rankLower.contains('capitán') || 
                           rankLower.contains('teniente') || 
                           rankLower.contains('ayudante') ||
                           rankLower.contains('general') ||
                           rankLower.contains('inspector');
          final isVolunteer = rankLower.contains('bombero');
          
          return isVolunteer && !isHonorary && !isOfficer;
        }
        
        // Para otras categorías, buscar si el cargo contiene alguna palabra clave
        return cargosInCategory.any((cargoKeyword) => 
          rankLower.contains(cargoKeyword.toLowerCase()));
      }).toList();

      if (usersInCategory.isEmpty) continue;

      groups.add(_buildCategorySection(categoryName, usersInCategory));
      groups.add(const SizedBox(height: 16));
    }

    return groups;
  }

  /// Construye una sección de categoría
  Widget _buildCategorySection(String categoryName, List<Map<String, dynamic>> users) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header de categoría
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            categoryName,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
        const SizedBox(height: 8),
        
        // Lista de usuarios en esta categoría
        ...users.asMap().entries.map((entry) {
          final globalIndex = _attendanceList.indexOf(entry.value);
          final item = entry.value;
          final user = item['user'] as UserModel;
          final status = item['status'] as AttendanceStatus;
          final isLocked = item['isLocked'] as bool;
          
          return _buildAttendanceRow(globalIndex, user, status, isLocked);
        }).toList(),
      ],
    );
  }

  /// Construye una fila de asistencia
  Widget _buildAttendanceRow(int index, UserModel user, AttendanceStatus status, bool isLocked) {
    Color statusColor;
    IconData statusIcon;
    
    if (status == AttendanceStatus.licencia) {
      statusColor = AppTheme.warningColor;
      statusIcon = Icons.lock;
    } else if (status == AttendanceStatus.present) {
      statusColor = AppTheme.efectivaColor;
      statusIcon = Icons.check_circle;
    } else {
      statusColor = Colors.grey;
      statusIcon = Icons.cancel;
    }
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          // Checkbox de asistencia
          SizedBox(
            width: 24,
            height: 24,
            child: isLocked
                ? Icon(Icons.lock, size: 18, color: AppTheme.warningColor)
                : Checkbox(
                    value: status == AttendanceStatus.present,
                    onChanged: (_) => _toggleAttendance(index),
                    activeColor: AppTheme.efectivaColor,
                  ),
          ),
          const SizedBox(width: 12),
          
          // Nombre y rango
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user.fullName,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                ),
                if (user.rank.isNotEmpty)
                  Text(
                    user.rank,
                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                  ),
              ],
            ),
          ),
          
          // Indicador de estado
          Icon(statusIcon, size: 20, color: statusColor),
        ],
      ),
    );
  }

  Widget _buildLegend(IconData icon, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}
