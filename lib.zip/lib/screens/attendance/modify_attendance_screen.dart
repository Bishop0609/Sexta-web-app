import 'package:flutter/material.dart';
import 'package:sexta_app/widgets/app_drawer.dart';
import 'package:sexta_app/widgets/branded_app_bar.dart';

// TODO: Implement attendance modification with role check
class ModifyAttendanceScreen extends StatelessWidget {
  const ModifyAttendanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const BrandedAppBar(title: 'Modificar Asistencia'),
      drawer: const AppDrawer(),
      body: const Center(
        child: Text('Module 4: Modify Attendance - To be implemented'),
      ),
    );
  }
}
