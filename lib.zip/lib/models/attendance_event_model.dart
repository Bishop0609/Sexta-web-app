import 'package:freezed_annotation/freezed_annotation.dart';

part 'attendance_event_model.freezed.dart';
part 'attendance_event_model.g.dart';

@freezed
class AttendanceEventModel with _$AttendanceEventModel {
  const factory AttendanceEventModel({
    required String id,
    required String actTypeId,
    required DateTime eventDate,
    required String createdBy,
    DateTime? createdAt,
  }) = _AttendanceEventModel;

  factory AttendanceEventModel.fromJson(Map<String, dynamic> json) =>
      _$AttendanceEventModelFromJson(json);
}
