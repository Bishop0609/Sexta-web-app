import 'package:sexta_app/models/user_model.dart';
import 'package:sexta_app/models/attendance_record_model.dart';
import 'package:sexta_app/services/supabase_service.dart';
import 'package:intl/intl.dart';

/// Servicio para gestión de asistencia con lógica de cross-check automático
class AttendanceService {
  final SupabaseService _supabase = SupabaseService();

  /// LÓGICA CRÍTICA: Verifica si un usuario tiene licencia aprobada para una fecha
  Future<bool> hasApprovedLicense(String userId, DateTime eventDate) async {
    final permissions = await _supabase.getActivePermissions(userId, eventDate);
    return permissions.isNotEmpty;
  }

  /// Prepara lista de asistencia con auto-check de licencias
  Future<List<Map<String, dynamic>>> prepareAttendanceList(
    List<UserModel> users,
    DateTime eventDate,
  ) async {
    final attendanceList = <Map<String, dynamic>>[];

    for (final user in users) {
      final hasLicense = await hasApprovedLicense(user.id, eventDate);
      
      attendanceList.add({
        'user': user,
        'status': hasLicense ? AttendanceStatus.licencia : AttendanceStatus.absent,
        'isLocked': hasLicense, // Bloquear edición si tiene licencia
        'hasLicense': hasLicense,
      });
    }

    return attendanceList;
  }

  /// Crea evento de asistencia con registros
  Future<String> createAttendanceEvent({
    required String actTypeId,
    required DateTime eventDate,
    required String createdBy,
    required List<Map<String, dynamic>> attendanceRecords,
  }) async {
    // 1. Crear evento
    final eventId = await _supabase.createAttendanceEvent({
      'act_type_id': actTypeId,
      'event_date': eventDate.toIso8601String().split('T')[0],
      'created_by': createdBy,
      'created_at': DateTime.now().toIso8601String(),
    });

    // 2. Crear registros de asistencia
    final records = attendanceRecords.map((record) {
      return {
        'event_id': eventId,
        'user_id': record['userId'],
        'status': record['status'],
        'is_locked': record['isLocked'] ?? false,
        'created_at': DateTime.now().toIso8601String(),
      };
    }).toList();

    await _supabase.createAttendanceRecords(records);

    return eventId;
  }

  /// Obtiene eventos de asistencia con información completa
  Future<List<Map<String, dynamic>>> getAttendanceEventsWithDetails() async {
    return await _supabase.getAttendanceEvents();
  }

  /// Obtiene registros de un evento específico
  Future<List<Map<String, dynamic>>> getEventAttendanceRecords(String eventId) async {
    return await _supabase.getAttendanceRecordsByEvent(eventId);
  }

  /// Actualiza un registro de asistencia (solo si no está bloqueado)
  Future<bool> updateAttendanceRecord({
    required String recordId,
    required AttendanceStatus newStatus,
    required bool isAdmin,
  }) async {
    // Obtener registro actual para verificar si está bloqueado
    final records = await _supabase.getAttendanceRecordsByEvent(recordId);
    if (records.isEmpty) return false;

    final record = records.first;
    final isLocked = record['is_locked'] as bool;

    // Solo admin puede editar registros bloqueados
    if (isLocked && !isAdmin) {
      throw Exception('No se puede modificar un registro con licencia activa. Solo administradores.');
    }

    await _supabase.updateAttendanceRecord(recordId, {
      'status': newStatus.name,
    });

    return true;
  }

  /// Calcula estadísticas individuales (Efectiva vs Abono)
  Future<Map<String, dynamic>> calculateIndividualStats(String userId) async {
    final supabaseClient = _supabase.client;

    // Query que une attendance_records con attendance_events y act_types
    final response = await supabaseClient
        .from('attendance_records')
        .select('''
          status,
          event:attendance_events!inner(
            act_type:act_types!inner(category)
          )
        ''')
        .eq('user_id', userId)
        .eq('status', 'present');

    final records = response as List;
    
    int efectivaCount = 0;
    int abonoCount = 0;

    for (final record in records) {
      final category = record['event']['act_type']['category'];
      if (category == 'efectiva') {
        efectivaCount++;
      } else if (category == 'abono') {
        abonoCount++;
      }
    }

    final total = efectivaCount + abonoCount;
    final efectivaPct = total > 0 ? (efectivaCount / total) * 100 : 0.0;
    final abonoPct = total > 0 ? (abonoCount / total) * 100 : 0.0;

    return {
      'efectiva_count': efectivaCount,
      'abono_count': abonoCount,
      'total': total,
      'efectiva_pct': efectivaPct,
      'abono_pct': abonoPct,
    };
  }

  /// Calcula estadísticas de la compañía por mes (últimos 6 meses)
  Future<List<Map<String, dynamic>>> calculateCompanyMonthlyStats() async {
    final supabaseClient = _supabase.client;
    final now = DateTime.now();
    final sixMonthsAgo = DateTime(now.year, now.month - 6, 1);

    final response = await supabaseClient
        .from('attendance_events')
        .select('''
          event_date,
          records:attendance_records!inner(
            status,
            event:attendance_events!inner(
              act_type:act_types!inner(category)
            )
          )
        ''')
        .gte('event_date', sixMonthsAgo.toIso8601String().split('T')[0]);

    final events = response as List;
    final monthlyData = <String, Map<String, int>>{};

    for (final event in events) {
      final eventDate = DateTime.parse(event['event_date']);
      final monthKey = DateFormat('yyyy-MM').format(eventDate);
      
      if (!monthlyData.containsKey(monthKey)) {
        monthlyData[monthKey] = {'efectiva': 0, 'abono': 0};
      }

      final records = event['records'] as List;
      for (final record in records) {
        if (record['status'] == 'present') {
          final category = record['event']['act_type']['category'];
          if (category == 'efectiva') {
            monthlyData[monthKey]!['efectiva'] = 
                (monthlyData[monthKey]!['efectiva'] ?? 0) + 1;
          } else if (category == 'abono') {
            monthlyData[monthKey]!['abono'] = 
                (monthlyData[monthKey]!['abono'] ?? 0) + 1;
          }
        }
      }
    }

    return monthlyData.entries.map((entry) {
      final parts = entry.key.split('-');
      return {
        'month': entry.key,
        'year': int.parse(parts[0]),
        'month_num': int.parse(parts[1]),
        'efectiva_count': entry.value['efectiva']!,
        'abono_count': entry.value['abono']!,
      };
    }).toList()
      ..sort((a, b) => (a['month'] as String).compareTo(b['month'] as String));
  }

  /// Ranking de asistencia (top performers)
  Future<List<Map<String, dynamic>>> getAttendanceRanking({int limit = 10}) async {
    final supabaseClient = _supabase.client;

    final response = await supabaseClient.rpc('get_attendance_ranking', params: {
      'limit_count': limit,
    });

    return (response as List).cast<Map<String, dynamic>>();
  }

  /// Alertas de baja asistencia (semáforo)
  Future<List<Map<String, dynamic>>> getLowAttendanceAlerts({
    double threshold = 0.70,
  }) async {
    final users = await _supabase.getAllUsers();
    final alerts = <Map<String, dynamic>>[];

    for (final user in users) {
      final stats = await calculateIndividualStats(user.id);
      final totalEvents = await _getTotalEventsCount();
      
      if (totalEvents == 0) continue;

      final attendancePct = (stats['total'] as int) / totalEvents;

      if (attendancePct < threshold) {
        alerts.add({
          'user_id': user.id,
          'full_name': user.fullName,
          'rank': user.rank,
          'attendance_pct': attendancePct * 100,
          'severity': attendancePct < 0.50 ? 'critical' : 'warning',
        });
      }
    }

    alerts.sort((a, b) => 
        (a['attendance_pct'] as double).compareTo(b['attendance_pct'] as double));

    return alerts;
  }

  Future<int> _getTotalEventsCount() async {
    final events = await _supabase.getAttendanceEvents();
    return events.length;
  }
}
