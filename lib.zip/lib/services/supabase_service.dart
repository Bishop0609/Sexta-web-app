import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:sexta_app/models/user_model.dart';
import 'package:intl/intl.dart';

class SupabaseService {
  final SupabaseClient client = Supabase.instance.client;

  // Singleton pattern
  static final SupabaseService _instance = SupabaseService._internal();

  factory SupabaseService() {
    return _instance;
  }

  SupabaseService._internal();

  // ===========================================================================
  // AUTHENTICATION & CREDENTIALS
  // ===========================================================================

  Future<AuthResponse> signIn(String email, String password) async {
    return await client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  Future<void> signOut() async {
    await client.auth.signOut();
  }

  Future<UserModel?> getUserByRut(String rut) async {
    try {
      final response = await client
          .from('users')
          .select()
          .eq('rut', rut)
          .maybeSingle();
      return response != null ? UserModel.fromJson(response) : null;
    } catch (e) {
      print('Error getting user by RUT: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>?> getAuthCredentials(String userId) async {
    try {
      final response = await client
          .from('auth_credentials')
          .select()
          .eq('user_id', userId)
          .maybeSingle();
      return response;
    } catch (e) {
      print('Error getting auth credentials: $e');
      return null;
    }
  }

  Future<void> createAuthCredentials(String userId, String passwordHash) async {
    await client.from('auth_credentials').insert({
      'user_id': userId,
      'password_hash': passwordHash,
      'failed_attempts': 0,
    });
  }

  Future<void> updatePassword(String userId, String newHash) async {
    await client.from('auth_credentials').update({
      'password_hash': newHash,
      'requires_password_change': false,
      'failed_attempts': 0,
      'locked_until': null,
    }).eq('user_id', userId);
  }

  Future<void> updatePasswordWithReset(String userId, String passwordHash) async {
    await client.from('auth_credentials').update({
      'password_hash': passwordHash,
      'requires_password_change': true,
      'failed_attempts': 0,
      'locked_until': null,
    }).eq('user_id', userId);
  }

  Future<void> incrementFailedAttempts(String userId) async {
    // Direct UPDATE to avoid missing RPC function error (PGRST202)
    final current = await client
        .from('auth_credentials')
        .select('failed_attempts')
        .eq('user_id', userId)
        .single();
    
    final newCount = ((current['failed_attempts'] as int?) ?? 0) + 1;
    await client.from('auth_credentials').update({
      'failed_attempts': newCount,
    }).eq('user_id', userId);
  }

  Future<void> resetFailedAttempts(String userId) async {
    await client.from('auth_credentials').update({
      'failed_attempts': 0,
      'locked_until': null,
    }).eq('user_id', userId);
  }

    Future<void> lockAccount(String userId, {required int minutes}) async {
    final lockedUntil = DateTime.now().add(Duration(minutes: minutes));
    await client.from('auth_credentials').update({
      'locked_until': lockedUntil.toIso8601String(),
    }).eq('user_id', userId);
  }

  Future<void> updateLastLogin(String userId) async {
    await client.from('auth_credentials').update({
      'last_login': DateTime.now().toIso8601String(),
    }).eq('user_id', userId);
  }

  // ===========================================================================
  // USER MANAGEMENT
  // ===========================================================================

  Future<UserModel?> getUserProfile(String userId) async {
    try {
      final response = await client
          .from('users')
          .select()
          .eq('id', userId)
          .maybeSingle();

      if (response == null) {
        return null;
      }

      return UserModel.fromJson(response);
    } catch (e) {
      print('Error getting user profile: $e');
      return null;
    }
  }

  Future<List<UserModel>> getAllUsers() async {
     try {
      final response = await client.from('users').select().order('victor_number');
      return (response as List).map((json) => UserModel.fromJson(json)).toList();
    } catch (e) {
      print('Error getting all users: $e');
      return [];
    }
  }

  Future<UserModel> createUser(UserModel user) async {
    final userData = user.toJson();
    final response = await client.from('users').insert(userData).select().single();
    return UserModel.fromJson(response);
  }

  Future<void> updateUser(UserModel user) async {
    await updateUserProfile(user); 
  }

  Future<void> updateUserProfile(UserModel user) async {
    await client.from('users').update({
      'full_name': user.fullName,
      'gender': user.gender == Gender.male ? 'M' : 'F',
      'marital_status': user.maritalStatus == MaritalStatus.single ? 'single' : 'married',
      'rank': user.rank,
      'role': user.role.name,
      'victor_number': user.victorNumber,
      'registro_compania': user.registroCompania,
      'payment_start_date': user.paymentStartDate?.toIso8601String(),
      'is_student': user.isStudent,
      'student_start_date': user.studentStartDate?.toIso8601String(),
      'student_end_date': user.studentEndDate?.toIso8601String(),
      'rut': user.rut,
      'email': user.email,
    }).eq('id', user.id);
  }

  Future<void> deleteUser(String userId) async {
    await client.from('users').delete().eq('id', userId);
  }

  // ===========================================================================
  // PERMISSIONS (LICENCIAS)
  // ===========================================================================

   Future<List<Map<String, dynamic>>> getPermissionsByUser(String userId) async {
    return await client.from('permissions').select().eq('user_id', userId).order('created_at', ascending: false);
  }

  Future<List<Map<String, dynamic>>> getPermissionsByStatus(String status) async {
     return await client.from('permissions')
     .select('*, user:users!user_id(*)')
     .eq('status', status)
     .order('created_at', ascending: false);
  }

  Future<Map<String, dynamic>> createPermission(Map<String, dynamic> data) async {
    return await client.from('permissions').insert(data).select().single();
  }

  Future<void> updatePermission(String id, Map<String, dynamic> data) async {
    await client.from('permissions').update(data).eq('id', id);
  }
  
  Future<void> updatePermissionStatus(String id, String status, String reviewedBy, {String? reason}) async {
    final Map<String, dynamic> data = {
      'status': status,
      'reviewed_by': reviewedBy,
      'reviewed_at': DateTime.now().toIso8601String(),
    };
    if (reason != null) data['rejection_reason'] = reason;
    await client.from('permissions').update(data).eq('id', id);
  }

  Future<List<Map<String, dynamic>>> getActivePermissions(String userId, DateTime date) async {
    final dateStr = DateFormat('yyyy-MM-dd').format(date);
    return await client.from('permissions')
      .select()
      .eq('user_id', userId)
      .eq('status', 'approved')
      .lte('start_date', dateStr)
      .gte('end_date', dateStr);
  }

  Future<List<Map<String, dynamic>>> getAllActivePermissionsForDate(DateTime date) async {
     final dateStr = DateFormat('yyyy-MM-dd').format(date);
     return await client.from('permissions')
      .select('*, user:users!user_id(*)')
      .eq('status', 'approved')
      .lte('start_date', dateStr)
      .gte('end_date', dateStr);
  }

  Future<List<Map<String, dynamic>>> getApprovedPermissionsBetweenDates(DateTime start, DateTime end, {String? userId}) async {
     final startStr = DateFormat('yyyy-MM-dd').format(start);
     final endStr = DateFormat('yyyy-MM-dd').format(end);
     
     var query = client.from('permissions')
      .select('*, user:users!user_id(*)')
      .eq('status', 'approved')
      .or('and(start_date.gte.$startStr,start_date.lte.$endStr),and(end_date.gte.$startStr,end_date.lte.$endStr),and(start_date.lte.$startStr,end_date.gte.$endStr)');
      
     if (userId != null) {
       query = query.eq('user_id', userId);
     }
     
     return await query;
  }

  // ===========================================================================
  // ACTIVITIES & ACT TYPES
  // ===========================================================================

  Future<List<Map<String, dynamic>>> getAllActTypes() async {
    return await client.from('act_types')
      .select()
      .eq('is_active', true)
      .order('name');
  }

  Future<void> createActType(Map<String, dynamic> data) async {
    await client.from('act_types').insert(data);
  }

  Future<void> updateActType(String id, Map<String, dynamic> data) async {
    await client.from('act_types').update(data).eq('id', id);
  }
  Future<void> deleteActType(String id) async {
    await client.from('act_types').delete().eq('id', id);
  }

  Future<List<Map<String, dynamic>>> getWeeklyActivities(DateTime startDate, DateTime endDate) async {
    final start = DateFormat('yyyy-MM-dd').format(startDate);
    final end = DateFormat('yyyy-MM-dd').format(endDate);

    try {
      print('[SupabaseService] getWeeklyActivities: $start to $end');
      final response = await client
          .from('activities')
          .select('*, creator:users!created_by(*)')
          .gte('activity_date', start)
          .lte('activity_date', end)
          .order('activity_date', ascending: true); // Retain original order by activity_date
      final activities = List<Map<String, dynamic>>.from(response);
      print('[SupabaseService] getWeeklyActivities: Found ${activities.length} activities');
      return activities;
    } catch (e) {
      print('❌ Error loading activities: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> getUpcomingActivities({int limit = 50}) async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    return await client.from('activities')
      .select('*, creator:users!created_by(*)')
      .gte('activity_date', today)
      .order('activity_date')
      .limit(limit);
  }

  Future<List<Map<String, dynamic>>> createActivity(Map<String, dynamic> data) async {
      final response = await client.from('activities').insert(data).select();
      return List<Map<String, dynamic>>.from(response);
  }

  Future<void> updateActivity(String id, Map<String, dynamic> data, String userId) async {
     final Map<String, dynamic> updateData = Map.from(data);
     updateData['modified_by'] = userId; 
     updateData['modified_at'] = DateTime.now().toIso8601String();
     await client.from('activities').update(updateData).eq('id', id);
  }

  Future<void> deleteActivity(String id) async {
    await client.from('activities').delete().eq('id', id);
  }

  // ===========================================================================
  // ATTENDANCE
  // ===========================================================================

  Future<String> createAttendanceEvent(Map<String, dynamic> data) async {
    final response = await client.from('attendance_events').insert(data).select().single();
    return response['id'] as String;
  }
  
  Future<void> createAttendanceRecords(List<Map<String, dynamic>> records) async {
    if (records.isEmpty) return;
    await client.from('attendance_records').insert(records);
  }

  Future<List<Map<String, dynamic>>> getAttendanceEvents() async {
    return await client.from('attendance_events')
      .select('*, act_type:act_types(*), creator:users!created_by(*)')
      .order('event_date', ascending: false);
  }

  Future<List<Map<String, dynamic>>> getAttendanceRecordsByEvent(String eventId) async {
    return await client.from('attendance_records')
      .select('*, user:users!user_id(*)')
      .eq('event_id', eventId)
      .order('user(victor_number)'); 
  }

  Future<void> updateAttendanceRecord(String id, Map<String, dynamic> data) async {
    await client.from('attendance_records').update(data).eq('id', id);
  }

  Future<void> updateAttendanceRecord2(String id, String status, bool isLocked) async {
    final Map<String, dynamic> data = {
      'status': status,
      'is_locked': isLocked,
    };
    await client.from('attendance_records').update(data).eq('id', id);
  }

  Future<void> deleteAttendanceEvent(String id) async {
    await client.from('attendance_records').delete().eq('event_id', id);
    await client.from('attendance_events').delete().eq('id', id);
  }

  Future<void> updateAttendanceEvent(
    String id, 
    DateTime date, 
    String actTypeId, 
    String modifiedBy, 
    {String? subtype, String? location}
  ) async {
    final Map<String, dynamic> data = {
      'event_date': date.toIso8601String().split('T')[0],
      'act_type_id': actTypeId,
      'modified_by': modifiedBy,
      'modified_at': DateTime.now().toIso8601String(),
    };
    if (subtype != null) data['subtype'] = subtype;
    if (location != null) data['location'] = location;
    
    await client.from('attendance_events').update(data).eq('id', id);
  }

  Future<void> getAttendanceHistory(String userId) async {
      // Stub as used in previous implementation
  }

  // ===========================================================================
  // SHIFTS (GUARDIAS)
  // ===========================================================================

  Future<int> getShiftRegistrationCount(DateTime date, String gender) async {
     final dateStr = DateFormat('yyyy-MM-dd').format(date);
     final count = await client.from('shift_registrations')
       .count(CountOption.exact)
       .eq('shift_date', dateStr)
       .eq('user.gender', gender == 'M' ? 'M' : 'F');
     return count;
  }

  Future<void> createShiftRegistration(Map<String, dynamic> data) async {
    await client.from('shift_registrations').insert(data);
  }

  Future<List<Map<String, dynamic>>> getShiftConfigurations() async {
    return await client.from('shift_configurations').select().eq('active', true).order('created_at');
  }

  Future<List<Map<String, dynamic>>> getShiftRegistrations(String configId) async {
    return await client.from('shift_registrations')
      .select('*, user:users!user_id(*)')
      .order('shift_date')
      .order('created_at'); 
  }

  Future<void> deleteShiftRegistration(String id) async {
    await client.from('shift_registrations').delete().eq('id', id);
  }

  Future<List<Map<String, dynamic>>> getShiftAttendance(DateTime date) async {
    final dateStr = DateFormat('yyyy-MM-dd').format(date);
    return await client.from('shift_attendance')
      .select('*, user:users!user_id(*), replacement:users!replacement_user_id(*)')
      .eq('shift_date', dateStr);
  }

  Future<void> createShiftAttendance(Map<String, dynamic> data) async {
    await client.from('shift_attendance').insert(data);
  }

  Future<Map<String, dynamic>?> getNextUserShift(String userId) async {
    try {
      final now = DateTime.now();
      final todayStr = DateFormat('yyyy-MM-dd').format(now);
      
      final response = await client
          .from('shift_registrations')
          .select()
          .eq('user_id', userId)
          .gte('shift_date', todayStr) 
          .order('shift_date', ascending: true)
          .limit(1)
          .maybeSingle();
          
      return response;
    } catch (e) {
      print('Error getting next shift: $e');
      return null;
    }
  }

}
