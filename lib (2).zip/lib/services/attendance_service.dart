import 'package:sexta_app/models/user_model.dart';
import 'package:sexta_app/models/attendance_record_model.dart';
import 'package:sexta_app/services/supabase_service.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

/// Servicio para gestión de asistencia con lógica de cross-check automático
class AttendanceService {
  final SupabaseService _supabase = SupabaseService();

  /// LÓGICA CRÍTICA: Verifica si un usuario tiene permiso aprobado para una fecha
  Future<bool> hasApprovedLicense(String userId, DateTime eventDate) async {
    final permissions = await _supabase.getActivePermissions(userId, eventDate);
    return permissions.isNotEmpty;
  }

  /// Prepares attendance list with auto-check of licenses (OPTIMIZED: batch load)
  Future<List<Map<String, dynamic>>> prepareAttendanceList(
    List<UserModel> users,
    DateTime eventDate, {
    String? actividadId,
  }) async {
    // OPTIMIZATION: Batch load ALL active licenses for this date in single query
    final allLicenses = await _supabase.getAllActivePermissionsForDate(eventDate);
    
    // Create a Set of user IDs that have active licenses for fast lookup
    final usersWithLicenses = <String>{};
    for (final license in allLicenses) {
      usersWithLicenses.add(license['user_id'] as String);
    }

    if (actividadId != null) {
      final permisosActividad = await _supabase.client.rpc(
        'get_permisos_por_actividad',
        params: {'p_actividad_id': actividadId},
      );
      for (final permiso in permisosActividad as List) {
        usersWithLicenses.add(permiso['user_id'] as String);
      }
    }

    final attendanceList = <Map<String, dynamic>>[];

    for (final user in users) {
      final hasLicense = usersWithLicenses.contains(user.id);
      
      attendanceList.add({
        'user': user,
        'status': hasLicense ? AttendanceStatus.permiso : AttendanceStatus.absent,
        'isLocked': hasLicense, // Bloquear edición si tiene permiso aprobado
        'hasLicense': hasLicense,
      });
    }

    return attendanceList;
  }

  /// Crea evento de asistencia con registros
  Future<String> createAttendanceEvent({
    required String actTypeId,
    required DateTime eventDate,
    required String createdBy,
    required List<Map<String, dynamic>> attendanceRecords,
    String? subtype,
    String? location,
    String? actividadId,
    String? modoAsistencia,
  }) async {
    // 1. Crear evento
    final eventData = {
      'act_type_id': actTypeId,
      'event_date': eventDate.toIso8601String().split('T')[0],
      'created_by': createdBy,
    };
    
    if (subtype != null) eventData['subtype'] = subtype;
    if (location != null) eventData['location'] = location;
    if (actividadId != null) eventData['actividad_id'] = actividadId;
    if (modoAsistencia != null) eventData['modo_asistencia'] = modoAsistencia;
    
    final eventId = await _supabase.createAttendanceEvent(eventData);

    // 2. Crear registros de asistencia
    final records = attendanceRecords.map((record) {
      return {
        'event_id': eventId,
        'user_id': record['userId'],
        'status': record['status'],
        'is_locked': record['isLocked'] ?? false,
      };
    }).toList();

    await _supabase.createAttendanceRecords(records);

    return eventId;
  }

  /// Obtiene eventos de asistencia con información completa
  Future<List<Map<String, dynamic>>> getAttendanceEventsWithDetails() async {
    return await _supabase.getAttendanceEvents();
  }

  /// Gets attendance records for specific event
  Future<List<Map<String, dynamic>>> getEventAttendanceRecords(String eventId) async {
    return await _supabase.getAttendanceRecordsByEvent(eventId);
  }

  /// Gets user's attendance history (most recent records)
  Future<List<Map<String, dynamic>>> getUserAttendanceHistory(String userId, int limit) async {
    final supabaseClient = _supabase.client;
    
    final response = await supabaseClient
        .from('attendance_records')
        .select('''
          *,
          event:attendance_events!inner(
            event_date,
            subtype,
            act_type:act_types!inner(name, category)
          )
        ''')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(limit);

    final records = response as List;
    
    // Flatten the structure for easier use
    return records.map((record) {
      return {
        'status': record['status'],
        'event_date': record['event']['event_date'],
        'act_type_name': record['event']['act_type']['name'],
        'act_type_category': record['event']['act_type']['category'],
        'subtype': record['event']['subtype'],
      };
    }).toList();
  }

  /// Actualiza un registro de asistencia (solo si no está bloqueado)
  Future<bool> updateAttendanceRecord({
    required String recordId,
    required AttendanceStatus newStatus,
    required bool isAdmin,
  }) async {
    // Obtener registro actual para verificar si está bloqueado
    final records = await _supabase.getAttendanceRecordsByEvent(recordId);
    if (records.isEmpty) return false;

    final record = records.first;
    final isLocked = record['is_locked'] as bool;

    // Solo admin puede editar registros bloqueados
    if (isLocked && !isAdmin) {
      throw Exception('No se puede modificar un registro con permiso activo. Solo administradores.');
    }

    await _supabase.updateAttendanceRecord(recordId, {
      'status': newStatus.name,
    });

    return true;
  }

  /// Calcula estadísticas individuales (Efectiva vs Abono) - DEPRECATED
  /// Use calculateCitationAndEmergencyStats instead
  Future<Map<String, dynamic>> calculateIndividualStats(String userId) async {
    final supabaseClient = _supabase.client;

    // Query que une attendance_records con attendance_events y act_types
    final response = await supabaseClient
        .from('attendance_records')
        .select('''
          status,
          event:attendance_events!inner(
            act_type:act_types!inner(category)
          )
        ''')
        .eq('user_id', userId)
        .eq('status', 'present');

    final records = response as List;
    
    int efectivaCount = 0;
    int abonoCount = 0;

    for (final record in records) {
      final category = record['event']['act_type']['category'];
      if (category == 'efectiva') {
        efectivaCount++;
      } else if (category == 'abono') {
        abonoCount++;
      }
    }

    final total = efectivaCount + abonoCount;
    final efectivaPct = total > 0 ? (efectivaCount / total) * 100 : 0.0;
    final abonoPct = total > 0 ? (abonoCount / total) * 100 : 0.0;

    return {
      'efectiva_count': efectivaCount,
      'abono_count': abonoCount,
      'total': total,
      'efectiva_pct': efectivaPct,
      'abono_pct': abonoPct,
    };
  }

  /// NEW: Calcula estadísticas de asistencia a citaciones y emergencias
  /// del mes actual para un usuario específico
  Future<Map<String, dynamic>> calculateCitationAndEmergencyStats(
    String userId, {
    int? month,
    int? year,
  }) async {
    final supabaseClient = _supabase.client;
    final now = DateTime.now();
    final targetMonth = month ?? now.month;
    final targetYear = year ?? now.year;
    final firstDayOfMonth = DateTime(targetYear, targetMonth, 1);
    final lastDayOfMonth = DateTime(targetYear, targetMonth + 1, 0);
    final firstDayOfYear = DateTime(targetYear, 1, 1);

    final response = await supabaseClient
        .from('attendance_records')
        .select('''
          status,
          event:attendance_events!inner(
            event_date,
            act_type:act_types!inner(name)
          )
        ''')
        .eq('user_id', userId)
        .eq('status', 'present')
        .gte('event.event_date', firstDayOfYear.toIso8601String().split('T')[0]);

    final records = response as List;
    
    // Contadores para MES ACTUAL
    int monthCitationCount = 0;
    int monthEmergencyCount = 0;
    
    // Contadores para AÑO ACUMULADO
    int yearCitationCount = 0;
    int yearEmergencyCount = 0;

    // Contar asistencias por tipo
    for (final record in records) {
      final eventDate = DateTime.parse(record['event']['event_date'] as String);
      final actTypeName = record['event']['act_type']['name'] as String;
      
      final isCitation = [
      'Academia de Compañía',
      'Academia de Cuerpo',
      'Reunión Ordinaria',
      'Reunión Extraordinaria',
      'Citación de Compañía',
      'Citación de Cuerpo',
      'Otra Actividad'
    ].contains(actTypeName);
    final isEmergency = actTypeName == 'Emergencia';
      
      // Contar para el AÑO
      if (isCitation) yearCitationCount++;
      if (isEmergency) yearEmergencyCount++;
      
      // Contar para el MES ACTUAL
      if (eventDate.month == targetMonth && eventDate.year == targetYear) {
        if (isCitation) monthCitationCount++;
        if (isEmergency) monthEmergencyCount++;
      }
    }

    // Obtener total de eventos del MES
    final monthEvents = await supabaseClient
        .from('attendance_events')
        .select('''
          act_type:act_types!inner(name)
        ''')
        .gte('event_date', firstDayOfMonth.toIso8601String().split('T')[0])
        .lte('event_date', lastDayOfMonth.toIso8601String().split('T')[0]);

    int monthTotalCitationEvents = 0;
    int monthTotalEmergencyEvents = 0;

    for (final event in monthEvents as List) {
      final actTypeName = event['act_type']['name'] as String;
      
      if ([
      'Academia de Compañía',
      'Academia de Cuerpo',
      'Reunión Ordinaria',
      'Reunión Extraordinaria',
      'Citación de Compañía',
      'Citación de Cuerpo',
      'Otra Actividad'
    ].contains(actTypeName)) {
      monthTotalCitationEvents++;
    } else if (actTypeName == 'Emergencia') {
      monthTotalEmergencyEvents++;
    }
    }

    // Obtener total de eventos del AÑO
    final yearEvents = await supabaseClient
        .from('attendance_events')
        .select('''
          act_type:act_types!inner(name)
        ''')
        .gte('event_date', firstDayOfYear.toIso8601String().split('T')[0])
        .lte('event_date', now.toIso8601String().split('T')[0]);

    int yearTotalCitationEvents = 0;
    int yearTotalEmergencyEvents = 0;

    for (final event in yearEvents as List) {
      final actTypeName = event['act_type']['name'] as String;
      
      if ([
      'Academia de Compañía',
      'Academia de Cuerpo',
      'Reunión Ordinaria',
      'Reunión Extraordinaria',
      'Citación de Compañía',
      'Citación de Cuerpo',
      'Otra Actividad'
    ].contains(actTypeName)) {
      yearTotalCitationEvents++;
    } else if (actTypeName == 'Emergencia') {
      yearTotalEmergencyEvents++;
    }
    }

    // Calcular porcentajes
    final monthCitationPct = monthTotalCitationEvents > 0 
        ? (monthCitationCount / monthTotalCitationEvents) * 100 
        : 0.0;
    final monthEmergencyPct = monthTotalEmergencyEvents > 0 
        ? (monthEmergencyCount / monthTotalEmergencyEvents) * 100 
        : 0.0;
        
    final yearCitationPct = yearTotalCitationEvents > 0 
        ? (yearCitationCount / yearTotalCitationEvents) * 100 
        : 0.0;
    final yearEmergencyPct = yearTotalEmergencyEvents > 0 
        ? (yearEmergencyCount / yearTotalEmergencyEvents) * 100 
        : 0.0;

    return {
      // MES ACTUAL
      'month_citation_count': monthCitationCount,
      'month_emergency_count': monthEmergencyCount,
      'month_total_citation_events': monthTotalCitationEvents,
      'month_total_emergency_events': monthTotalEmergencyEvents,
      'month_citation_pct': monthCitationPct,
      'month_emergency_pct': monthEmergencyPct,
      
      // AÑO ACUMULADO
      'year_citation_count': yearCitationCount,
      'year_emergency_count': yearEmergencyCount,
      'year_total_citation_events': yearTotalCitationEvents,
      'year_total_emergency_events': yearTotalEmergencyEvents,
      'year_citation_pct': yearCitationPct,
      'year_emergency_pct': yearEmergencyPct,
      
      // Metadata
      'month_name': DateFormat('MMMM', 'es_ES').format(DateTime(targetYear, targetMonth)),
      'year': now.year,
    };
  }

  /// NEW: Calcula estadísticas mensuales de citaciones y emergencias
  /// para los últimos 6 meses de un usuario específico
  Future<List<Map<String, dynamic>>> calculateMonthlyAttendanceByType(String userId) async {
    final supabaseClient = _supabase.client;
    final now = DateTime.now();
    final sixMonthsAgo = DateTime(now.year, now.month - 5, 1);

    // Obtener todos los registros (sin filtro de fecha en query)
    final response = await supabaseClient
        .from('attendance_records')
        .select('''
          status,
          event:attendance_events!inner(
            event_date,
            act_type:act_types!inner(name)
          )
        ''')
        .eq('user_id', userId)
        .eq('status', 'present');

    final records = response as List;
    
    // Agrupar por mes (filtrar fechas en código)
    final Map<String, Map<String, int>> monthlyData = {};
    
    for (final record in records) {
      final eventDate = DateTime.parse(record['event']['event_date'] as String);
      
      // Solo procesar si está en los últimos 6 meses
      if (eventDate.isAfter(sixMonthsAgo.subtract(const Duration(days: 1)))) {
        final monthKey = '${eventDate.year}-${eventDate.month.toString().padLeft(2, '0')}';
        final actTypeName = record['event']['act_type']['name'] as String;
        
        if (!monthlyData.containsKey(monthKey)) {
          monthlyData[monthKey] = {
            'citation': 0,
            'emergency': 0,
            'month_num': eventDate.month,
            'year': eventDate.year,
          };
        }
        
        const citationTypes = [
          'Academia de Compañía', 'Academia de Cuerpo',
          'Reunión Ordinaria', 'Reunión Extraordinaria',
          'Citación de Compañía', 'Citación de Cuerpo',
          'Otra Actividad',
        ];
        if (citationTypes.contains(actTypeName)) {
          monthlyData[monthKey]!['citation'] = (monthlyData[monthKey]!['citation'] ?? 0) + 1;
        } else if (actTypeName == 'Emergencia') {
          monthlyData[monthKey]!['emergency'] = (monthlyData[monthKey]!['emergency'] ?? 0) + 1;
        }
      }
    }

    // Convertir a lista y ordenar por fecha
    final result = monthlyData.entries.map((entry) {
      return {
        'month_key': entry.key,
        'month_num': entry.value['month_num'],
        'year': entry.value['year'],
        'citation_count': entry.value['citation'],
        'emergency_count': entry.value['emergency'],
      };
    }).toList();

    result.sort((a, b) {
      final dateA = DateTime(a['year'] as int, a['month_num'] as int);
      final dateB = DateTime(b['year'] as int, b['month_num'] as int);
      return dateA.compareTo(dateB);
    });

    // Asegurar que siempre devolvemos 6 meses (rellenar con ceros si es necesario)
    final completeResult = <Map<String, dynamic>>[];
    for (int i = 5; i >= 0; i--) {
      final targetDate = DateTime(now.year, now.month - i, 1);
      final monthKey = '${targetDate.year}-${targetDate.month.toString().padLeft(2, '0')}';
      
      final existing = result.firstWhere(
        (r) => r['month_key'] == monthKey,
        orElse: () => {
          'month_key': monthKey,
          'month_num': targetDate.month,
          'year': targetDate.year,
          'citation_count': 0,
          'emergency_count': 0,
        },
      );
      
      completeResult.add(existing);
    }

    return completeResult;
  }

  /// Calcula estadísticas de la compañía por mes (últimos 6 meses) - OPTIMIZADO con RPC
  Future<List<Map<String, dynamic>>> calculateCompanyMonthlyStats() async {
    final supabaseClient = _supabase.client;

    // Llamar a la función RPC que hace la agregación en el servidor
    final response = await supabaseClient.rpc('get_monthly_stats');

    return (response as List).cast<Map<String, dynamic>>();
  }

  /// Ranking de asistencia (top performers)
  Future<List<Map<String, dynamic>>> getAttendanceRanking({int limit = 10}) async {
    final supabaseClient = _supabase.client;

    final response = await supabaseClient.rpc('get_attendance_ranking', params: {
      'limit_count': limit,
    });

    return (response as List).cast<Map<String, dynamic>>();
  }

  /// Alertas de baja asistencia (semáforo)
  /// TEMPORALMENTE DESHABILITADO - Era muy lento (iteraba todos los usuarios)
  /// TODO: Crear RPC en Supabase para calcular esto en el servidor
  Future<List<Map<String, dynamic>>> getLowAttendanceAlerts({
    double threshold = 0.70,
  }) async {
    // Retornar lista vacía temporalmente para mejorar performance
    // En producción, esto debería ser un RPC que calcule en el servidor
    return [];
  }

  // =====================================================
  // MÓDULO HISTORIAL DE ASISTENCIAS
  // =====================================================

  /// Obtiene asistencias recientes (últimas 2 horas) para historial
  /// Visible para todos los usuarios
  Future<List<Map<String, dynamic>>> getRecentAttendanceHistory() async {
    final supabaseClient = _supabase.client;
    final twoHoursAgo = DateTime.now().toUtc().subtract(const Duration(hours: 2));
    
    final response = await supabaseClient
        .from('attendance_events')
        .select('''
          *,
          act_types(name),
          users!attendance_events_created_by_fkey(full_name)
        ''')
        .gte('created_at', twoHoursAgo.toIso8601String())
        .order('created_at', ascending: false);
        
    // Calcular totales para cada evento
    final events = response as List;
    final eventsWithTotals = <Map<String, dynamic>>[];
    
    for (final event in events) {
      final eventId = event['id'] as String;
      final records = await getEventAttendanceRecords(eventId);
      
      int present = 0, absent = 0, permiso = 0;
      for (final record in records) {
        switch (record['status']) {
          case 'present': present++; break;
          case 'absent': absent++; break;
          case 'permiso': permiso++; break;
        }
      }
      
      eventsWithTotals.add({
        ...event,
        'total_present': present,
        'total_absent': absent,
        'total_licencia': permiso,
      });
    }
    
    return eventsWithTotals;
  }

  /// Valida si una asistencia puede ser editada
  /// Requisitos: < 1 hora de antigüedad Y usuario es el creador
  bool canEditAttendance({
    required DateTime createdAt,
    required String createdBy,
    required String currentUserId,
  }) {
    final now = DateTime.now();
    final hoursSinceCreation = now.difference(createdAt).inHours;
    
    return hoursSinceCreation < 1 && createdBy == currentUserId;
  }

  /// Actualiza registros de asistencia con validación de permisos
  /// Solo permite cambiar presente/ausente, NO permite modificar usuarios con permiso (locked)
  Future<bool> updateAttendanceWithValidation({
    required String eventId,
    required String currentUserId,
    required List<Map<String, dynamic>> updatedRecords,
  }) async {
    final supabaseClient = _supabase.client;
    
    // 1. Verificar que el evento existe y obtener datos
    final event = await supabaseClient
        .from('attendance_events')
        .select('created_at, created_by')
        .eq('id', eventId)
        .single();
        
    // 2. Validar permisos de edición
    if (!canEditAttendance(
      createdAt: DateTime.parse(event['created_at'] as String),
      createdBy: event['created_by'] as String,
      currentUserId: currentUserId,
    )) {
      throw Exception('No tienes permiso para editar esta asistencia o el tiempo de edición ha expirado');
    }
    
    // 3. Actualizar solo registros no bloqueados
    for (final record in updatedRecords) {
      if (record['is_locked'] == true) {
        continue; // No modificar usuarios con permiso
      }
      
      await supabaseClient
          .from('attendance_records')
          .update({
            'status': record['status'],
            'modified_at': DateTime.now().toIso8601String(),
          })
          .eq('id', record['id']);
    }
    
    return true;
  }

  /// Aprueba la revisión de una asistencia (solo usuarios con permiso de modificar asistencias)
  Future<bool> approveAttendanceReview({
    required String eventId,
    required String reviewerId,
  }) async {
    final supabaseClient = _supabase.client;
    
    await supabaseClient
        .from('attendance_events')
        .update({
          'estado_revision': 'revisada',
          'revisado_por': reviewerId,
          'fecha_revision': DateTime.now().toIso8601String(),
        })
        .eq('id', eventId);
        
    return true;
  }

  /// Obtiene el contador de asistencias pendientes de revisión
  Future<int> getPendingReviewCount() async {
    final supabaseClient = _supabase.client;
    
    final response = await supabaseClient
        .from('attendance_events')
        .select()
        .eq('estado_revision', 'pendiente')
        .count();
        
    return response.count;
  }

  /// Obtiene lista de asistencias pendientes de revisión
  Future<List<Map<String, dynamic>>> getPendingReviewAttendances() async {
    final supabaseClient = _supabase.client;
    
    final response = await supabaseClient
        .from('attendance_events')
        .select('''
          *,
          act_types(name),
          users!attendance_events_created_by_fkey(full_name)
        ''')
        .eq('estado_revision', 'pendiente')
        .order('created_at', ascending: false);
        
    return List<Map<String, dynamic>>.from(response as List);
  }

  Future<int> _getTotalEventsCount() async {
    final events = await _supabase.getAttendanceEvents();
    return events.length;
  }
}
